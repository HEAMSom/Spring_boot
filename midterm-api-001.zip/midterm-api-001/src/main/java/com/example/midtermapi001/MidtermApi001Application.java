package com.example.midtermapi001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidtermApi001Application {

    public static void main(String[] args) {
        SpringApplication.run(MidtermApi001Application.class, args);
    }

}
